# Imports
import plotly.graph_objects as go
import streamlit as st
import datetime as dt
import os
from pathlib import Path
import pandas as pd
import yfinance as yf
from statsmodels.tsa.ar_model import AutoReg

# Configure the page
st.set_page_config(
    page_title="Crypto Price Prediction",
    page_icon="💰",
)

# Create function to fetch cryptocurrencies
def fetch_cryptos():
    # Define popular cryptocurrencies and their tickers
    crypto_dict = {
        "Bitcoin": "BTC-USD",
        "Ethereum": "ETH-USD",
        "Binance Coin": "BNB-USD",
        "Ripple": "XRP-USD",
        "Cardano": "ADA-USD",
        "Solana": "SOL-USD",
        "Dogecoin": "DOGE-USD",
        "Polkadot": "DOT-USD",
        "Litecoin": "LTC-USD",
        "Shiba Inu": "SHIB-USD",
    }
    return crypto_dict

# Create function to fetch periods and intervals
def fetch_periods_intervals():
    periods = {
        "1d": ["1m", "2m", "5m", "15m", "30m", "60m", "90m"],
        "5d": ["1m", "2m", "5m", "15m", "30m", "60m", "90m"],
        "1mo": ["30m", "60m", "90m", "1d"],
        "3mo": ["1d", "5d", "1wk", "1mo"],
        "6mo": ["1d", "5d", "1wk", "1mo"],
        "1y": ["1d", "5d", "1wk", "1mo"],
        "2y": ["1d", "5d", "1wk", "1mo"],
        "5y": ["1d", "5d", "1wk", "1mo"],
        "max": ["1d", "5d", "1wk", "1mo"],
    }
    return periods

# Function to fetch cryptocurrency history
def fetch_crypto_history(crypto_ticker, period, interval):
    crypto_data = yf.Ticker(crypto_ticker)
    crypto_data_history = crypto_data.history(period=period, interval=interval)[
        ["Open", "High", "Low", "Close"]
    ]
    return crypto_data_history


# Function to generate cryptocurrency price prediction
def generate_crypto_prediction(crypto_ticker):
    try:
        crypto_data = yf.Ticker(crypto_ticker)
        crypto_data_hist = crypto_data.history(period="2y", interval="1d")
        crypto_data_close = crypto_data_hist[["Close"]].asfreq("D", method="ffill").ffill()

        train_df = crypto_data_close.iloc[: int(len(crypto_data_close) * 0.9) + 1]
        test_df = crypto_data_close.iloc[int(len(crypto_data_close) * 0.9) :]

        model = AutoReg(train_df["Close"], 250).fit(cov_type="HC0")

        predictions = model.predict(
            start=test_df.index[0], end=test_df.index[-1], dynamic=True
        )
        forecast = model.predict(
            start=test_df.index[0],
            end=test_df.index[-1] + dt.timedelta(days=90),
            dynamic=True,
        )
        return train_df, test_df, forecast, predictions
    except:
        return None, None, None, None

##### Sidebar Start #####

st.sidebar.markdown("## **User Input Features**")
crypto_dict = fetch_cryptos()

st.sidebar.markdown("### **Select Cryptocurrency**")
crypto = st.sidebar.selectbox("Choose a cryptocurrency", list(crypto_dict.keys()))

crypto_ticker = crypto_dict[crypto]

st.sidebar.markdown("### **Crypto Ticker**")
st.sidebar.text_input(
    label="Crypto ticker code", placeholder=crypto_ticker, disabled=True
)

periods = fetch_periods_intervals()

st.sidebar.markdown("### **Select Period**")
period = st.sidebar.selectbox("Choose a period", list(periods.keys()))

st.sidebar.markdown("### **Select Interval**")
interval = st.sidebar.selectbox("Choose an interval", periods[period])

##### Sidebar End #####

##### Title #####

st.markdown("# **Cryptocurrency Price Prediction**")
st.markdown("##### **Make Smarter Crypto Trades with Data-Driven Insights**")

##### Title End #####

##### Historical Data #####

crypto_data = fetch_crypto_history(crypto_ticker, period, interval)

st.markdown("## **Historical Data**")
fig = go.Figure(
    data=[
        go.Candlestick(
            x=crypto_data.index,
            open=crypto_data["Open"],
            high=crypto_data["High"],
            low=crypto_data["Low"],
            close=crypto_data["Close"],
        )
    ]
)
fig.update_layout(xaxis_rangeslider_visible=False)
st.plotly_chart(fig, use_container_width=True)

##### Prediction #####

train_df, test_df, forecast, predictions = generate_crypto_prediction(crypto_ticker)

if train_df is not None and (forecast >= 0).all() and (predictions >= 0).all():
    st.markdown("## **Crypto Prediction**")
    fig = go.Figure(
        data=[
            go.Scatter(
                x=train_df.index,
                y=train_df["Close"],
                name="Train",
                mode="lines",
                line=dict(color="blue"),
            ),
            go.Scatter(
                x=test_df.index,
                y=test_df["Close"],
                name="Test",
                mode="lines",
                line=dict(color="orange"),
            ),
            go.Scatter(
                x=forecast.index,
                y=forecast,
                name="Forecast",
                mode="lines",
                line=dict(color="red"),
            ),
            go.Scatter(
                x=test_df.index,
                y=predictions,
                name="Test Predictions",
                mode="lines",
                line=dict(color="green"),
            ),
        ]
    )
    fig.update_layout(xaxis_rangeslider_visible=False)
    st.plotly_chart(fig, use_container_width=True)

    ##### Recommendation Section #####

    # Get the most recent closing price and the predicted price
    latest_close_price = crypto_data["Close"].iloc[-1]
    predicted_price = forecast.iloc[-1]

    # Determine recommendation
    recommendation = "HOLD"
    if predicted_price > latest_close_price:
        recommendation = "BUY"
    elif predicted_price < latest_close_price:
        recommendation = "SELL"

    # Display the recommendation bar
    st.markdown("## **Recommendation**")
    st.metric(
        label="Action",
        value=recommendation,
        delta=f"{predicted_price - latest_close_price:.2f}",
        delta_color="inverse" if recommendation == "BUY" else "normal",
    )
else:
    st.markdown("## **Crypto Prediction**")
    st.markdown("### **No data available for the selected cryptocurrency**")

    # Fallback recommendation message
    st.markdown("## **Recommendation**")
    st.markdown("### **No recommendation available**")

##### Prediction End #####

##### Recommendations for Full Month and Year #####

def generate_recommendations_table(crypto_ticker, duration):
    """
    Generate a DataFrame with buy/sell recommendations for a given duration.
    """
    try:
        # Determine the start date for the specified duration
        if duration == "month":
            start_date = dt.datetime.now() - dt.timedelta(days=30)
        elif duration == "year":
            start_date = dt.datetime.now() - dt.timedelta(days=365)
        else:
            return None

        # Fetch historical data for the specified duration
        crypto_data = yf.Ticker(crypto_ticker)
        crypto_history = crypto_data.history(start=start_date, interval="1d")

        if crypto_history.empty:
            return None

        # Use the prediction model to get the forecast
        _, _, forecast, _ = generate_crypto_prediction(crypto_ticker)

        if forecast is None or forecast.empty:
            return None

        # Align the forecast with historical data
        forecast = forecast.reindex(crypto_history.index, method='nearest')

        # Add the forecast as Predicted_Close
        crypto_history["Predicted_Close"] = forecast

        # Generate recommendations based on Predicted_Close and Close
        crypto_history["Recommendation"] = "HOLD"
        for i in range(len(crypto_history)):
            today_close = crypto_history.iloc[i]["Close"]
            predicted_close = crypto_history.iloc[i]["Predicted_Close"]
            if pd.notna(predicted_close):  # Only generate recommendations if prediction exists
                if predicted_close > today_close:
                    crypto_history.at[crypto_history.index[i], "Recommendation"] = "BUY"
                elif predicted_close < today_close:
                    crypto_history.at[crypto_history.index[i], "Recommendation"] = "SELL"

        # Select only relevant columns for display
        return crypto_history[["Close", "Predicted_Close", "Recommendation"]]
    except Exception as e:
        st.error(f"Error generating recommendations: {e}")
        return None




# Generate recommendations for the last month
st.markdown("## **Monthly Recommendations**")
monthly_recommendations = generate_recommendations_table(crypto_ticker, "month")
if monthly_recommendations is not None:
    st.dataframe(monthly_recommendations)
else:
    st.write("No data available for the past month.")

# Generate recommendations for the last year
st.markdown("## **Yearly Recommendations**")
yearly_recommendations = generate_recommendations_table(crypto_ticker, "year")
if yearly_recommendations is not None:
    st.dataframe(yearly_recommendations)
else:
    st.write("No data available for the past year.")

# Add bar chart for yearly buy/sell/hold ratios
if yearly_recommendations is not None:
    # Count the occurrences of each recommendation
    recommendation_counts = yearly_recommendations["Recommendation"].value_counts()
    recommendations_df = recommendation_counts.reset_index()
    recommendations_df.columns = ["Recommendation", "Count"]

    # Plot the bar chart using Plotly
    st.markdown("## **Yearly Buy/Sell/Hold Ratios**")
    bar_fig = go.Figure(
        data=[
            go.Bar(
                x=recommendations_df["Recommendation"],
                y=recommendations_df["Count"],
                marker_color=["green", "red", "blue"],  # BUY -> Green, SELL -> Red, HOLD -> Blue
            )
        ]
    )
    bar_fig.update_layout(
        title="Buy/Sell/Hold Ratios for the Past Year",
        xaxis_title="Recommendation",
        yaxis_title="Count",
        template="plotly_white",
    )
    st.plotly_chart(bar_fig, use_container_width=True)

# Add a stacked bar chart for Buy/Sell/Hold ratios across all months in the past year
if yearly_recommendations is not None:
    # Extract the month from the index
    yearly_recommendations["Month"] = yearly_recommendations.index.month_name()

    # Group data by month and count recommendations
    monthly_counts = (
        yearly_recommendations.groupby(["Month", "Recommendation"]).size().unstack(fill_value=0)
    )

    # Ensure all recommendation categories are present (BUY, SELL, HOLD)
    monthly_counts = monthly_counts.reindex(columns=["BUY", "SELL", "HOLD"], fill_value=0)

    # Calculate ratios for each month
    monthly_ratios = monthly_counts.div(monthly_counts.sum(axis=1), axis=0)

    # Sort months in calendar order
    month_order = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ]
    monthly_ratios = monthly_ratios.loc[month_order].dropna()

    # Plot the stacked bar chart
    st.markdown("## **Monthly Buy/Sell/Hold Ratios (Past Year)**")
    stacked_bar_fig = go.Figure()

    # Add bars for each recommendation category
    for recommendation, color in zip(["BUY", "SELL", "HOLD"], ["green", "red", "blue"]):
        stacked_bar_fig.add_trace(
            go.Bar(
                name=recommendation,
                x=monthly_ratios.index,
                y=monthly_ratios[recommendation],
                marker_color=color,
            )
        )

    # Update layout for the chart
    stacked_bar_fig.update_layout(
        barmode="stack",  # Stack the bars
        title="Monthly Buy/Sell/Hold Ratios",
        xaxis_title="Month",
        yaxis_title="Ratio",
        template="plotly_white",
        xaxis=dict(tickmode="linear"),  # Ensure all months are shown
    )
    st.plotly_chart(stacked_bar_fig, use_container_width=True)
else:
    st.write("No data available for the past year.")
